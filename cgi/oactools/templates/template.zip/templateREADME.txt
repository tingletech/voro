The template cgi program used to generate the encoding, including several sample templates, 
is available for downloading at: http://www.cdlib.org/inside/projects/oac/toolkit/templates/template.zip. 
Please note that there is currently is no documentation, however, on implementing template syntax or 
using the cgi program to create your own template.

The template.zip file contains the following:

config files/:
   template (/cdldir/prod/cgi-bin/oactools)
   ead.dtd  (/cdldir/prod/cgi-bin/oactools)
   oacead.cfg (/cdldir/prod/htdocs/inside/projects/oac/toolkit/templates)
   
templates/:
   hoover.cfg (/cdldir/prod/htdocs/inside/projects/oac/toolkit/templates/oacead)
   cst-mss.cfg (/cdldir/prod/htdocs/inside/projects/oac/toolkit/templates/oacead)
   csl.cfg (/cdldir/prod/htdocs/inside/projects/oac/toolkit/templates/oacead)
   sdhists.cfg (/cdldir/prod/htdocs/inside/projects/oac/toolkit/templates/oacead)
   ucla-spcoll.cfg (/cdldir/prod/htdocs/inside/projects/oac/toolkit/templates/oacead)

extensions/:
   oacead.ext (/cdldir/prod/cgi-bin/oactools/extensions)

template usage help file/
   templates_help.pdf (/cdldir/prod/htdocs/inside/projects/oac/toolkit/templates/)

template read me file/
   templateREADME.txt (/template.zip)
   
LAST MODIFED: 09/18/09
